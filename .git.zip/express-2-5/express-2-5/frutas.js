const frut = ['platano','manzana','platano','pera']
const dinero = 1000;

module.exports = {frut,dinero};