///modelo de tabla
const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const tablaSchema = new Schema(
   {
    compania: {type: String},
    contacto: {type: String},
    pais: {type: String}
},{collections: "clientes"}
);


///crear el modelo
const Tabla = mongoose.model('Tabla',tablaSchema);

module.exports= Tabla;