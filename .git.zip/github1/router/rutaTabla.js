const express = require('express');
const router = express.Router();

const Tabla = require('../models/model-tabla');
router.get('/', async(req,res)=>{
    try{
     const arrayTablaBD = await Tabla.find()
     console.log("----"+arrayTablaBD.length);
     console.log(arrayTablaBD);
    
    
     res.render("tabla",{ tituloTabla:"titulo desde tabla bd",
     arrayTabla : arrayTablaBD
       //arrayTabla: [
        //    {id:'dke', compania: 'rex', contacto:'rexDescripcion', pais:'cr' }
        // ]
     
     ///
    
 
 }); 
 
 }catch(error){
     console.log(error);
 }
 
 })
 
 module.exports = router;